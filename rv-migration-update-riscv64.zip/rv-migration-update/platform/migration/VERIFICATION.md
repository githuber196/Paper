# 迁移模块本地验证与实机进度

更新日期：2026-10-12。当前包含默认 CrossNode 和新增 SameNode。Windows/amd64 本地检查与用户回传的服务器输出分别记录。

## 1. 本次本地测试

| 检查 | 已执行结果 | 范围 |
|---|---|---|
| Python 控制器 | 16 项通过 | 两种模式的状态机、UID、失败保留、显式模式、旧运行时拒绝、sudo 参数引用 |
| Go 迁移程序 | 实际 Go 1.21.13：8 项通过，无跳过 | 归档、授权、完整性、本机归档复核、精确镜像 digest、普通 CRI 转发、Unix socket/gRPC |
| containerd 缓存策略 | 实际 Go 1.23.12：3 项通过 | 命中完整缓存不拉取、缓存缺失回退、非 NotFound 错误保留 |
| Linux/riscv64 | 迁移程序与修补 daemon 交叉编译成功 | 目标为静态 Go ELF，不是原生执行 |

Python 测试模拟 K8s/SSH 节点接口；缓存策略测试使用传入的假 get/check/pull 函数，不等于对真实 content store 或 CRI 恢复的集成测试。Go 代理测试有真实本地 Unix socket 和 gRPC，上游服务仍为测试对象。最终脚本/文档/配置/包校验结果记录在 RELEASE-CHECKS.json。

## 2. 交付二进制

| 文件 | 构建机编译器 | 大小 | SHA256 |
|---|---|---|---|
| bin/rv-migrate-runtime | Go 1.21.13 | 15728640 | 179a48a74f4412268e787c054f97033c113680f125fd23c211fb042f7f4df407 |
| offline-runtime/bin/containerd | Go 1.23.12 | 37355672 | 3958a4f7ccae237da44443b7debe67f4ad698183c1758dfb19fb971488c886c0 |

两者 CGO_ENABLED=0、GOOS=linux、GOARCH=riscv64，ELF e_machine=243，无 PT_INTERP/PT_DYNAMIC。daemon 编译目标 GORISCV64=rva20u64。两个编译器下载包均经过官方 SHA256 核对。预编译程序不要求服务器安装编译器。

daemon 基于上游 containerd v2.1.5 / fcd43222d6b07379a4be9786bda52438f0dd16a1，只在 CRI 检查点恢复获取基础镜像处增加缓存优先分支；版本标为 v2.1.5-rv1。补丁检查原文件 SHA256，源码、构建脚本、依赖构建信息与许可证随包提供。stock 2.1.5 的三程序目录未修改，原升级清单继续可用。

## 3. 用户已经回传确认的实机进度

- openEuler 24.03 / riscv64 / 内核 6.1.80-lzu-ram+ / cgroup v1。
- runc 1.1.8，CRIU 4.1；基础 criu check 退出码 0。
- containerd 已经按 1.6 → 2.0.13 → stock 2.1.5 完成升级；节点 Ready，系统 Pod 为 Running。
- rv-migration-proxy 已接入；kubelet runtime/image endpoint 都指向 /run/rv-migration/cri.sock；预检读到实际 daemon v2.1.5。
- k8snode1 已 uncordon。控制端迁移控制器尚未提供安装成功输出。

这是新补充包安装前的状态，不能写成 rv1 和 SameNode 已在实机通过。

## 4. 接下来需要服务器确认

1. 更新到 v2.1.5-rv1 和 v2 迁移程序后，systemd/CRI 代理/节点状态正确。
2. SSH 专用密钥与 sudo 通道、迁移 CRD/RBAC/控制器安装正确。
3. SameNode：真实检查点停止源进程，新 Pod UID 恢复且内存 boot_id 保持、计数继续。
4. 第二个 Worker 就绪后，CrossNode 的实际传输、恢复与内存连续性。
5. 故障保留、容器生命周期和实际停顿记录。

SameNode 只验证本机恢复，不代表跨节点功能验收。已有 TCP 续接、外部卷/设备/Deployment/StatefulSet 状态迁移、节点宕机自动接管、自动回滚和多控制机 leader election 仍在当前实现范围之外。允许停顿的要求已落实，不增加预拷贝或零停顿优化。
