# RISC-V Kubernetes 监控离线部署

适用：Kubernetes 1.29.1，openEuler RISC-V，控制端 k8smaster / 192.168.102.130，工作端 k8snode1 / 192.168.102.125。

本次部署包只包含源码、Helm Chart 和文档。两个镜像已由用户导入工作端，并在实机运行版本检查：Prometheus 3.13.4、Grafana 12.0.0。Prometheus 显示的 Go 1.26.8 是构建版本，运行镜像不要求安装该 Go 版本。

## 1. 组件与访问地址

| 组件 | 运行位置 | 控制端访问地址 |
| --- | --- | --- |
| Helm / 安装器 / 验证脚本 | 控制端 | 本地命令 |
| Prometheus Pod | 工作端 k8snode1 | http://192.168.102.125:30090 |
| Grafana Pod | 工作端 k8snode1 | http://192.168.102.125:30300 |
| rv-node-exporter | 工作端 systemd 服务 | http://192.168.102.125:9108/metrics |

Chart 使用本地镜像名称，离线安装器强制 imagePullPolicy 为 Never。两种镜像都需要导入将参与运行监控 Pod 的工作节点；当前 nodeSelector 固定为 k8snode1。

Grafana 显式运行 /usr/bin/grafana server，使用镜像内 /etc/grafana.ini 和 /usr/share/grafana。数据、日志、插件和 provisioning 目录显式设置，运行 UID/GID 为 472。禁用插件预安装和更新检查。Prometheus 使用 UID/GID 65534。

当前使用 emptyDir：容器重启通常保留 Pod 卷，Pod 被删除或重建后历史指标、Grafana 数据库和手工修改会丢失。预置仪表盘、数据源和 Secret 会重新挂载。长期保存数据需要配置 PVC、存储类及其备份；本次配置未包含持久化存储。

## 2. 在电脑上上传到原 Paper 仓库

下载 rv-monitoring-setup.zip，保留 ZIP 文件，将它复制到电脑上的 Paper 仓库根目录。本包很小，可以直接作为普通 Git 文件提交。

电脑上的 Paper 仓库根目录，使用 Git Bash：

```bash
git add -- rv-monitoring-setup.zip
```

```bash
git commit -m "Add offline monitoring deployment"
```

```bash
git push origin main
```

也可以通过 GitHub 仓库 Add file → Upload files 上传这个 ZIP 文件。

## 3. 控制端取得并解压部署包

下列命令按前面约定的下载仓库目录 $HOME/rv-offline-download/Paper 编写。如果仓库放在别处，将 RV_PAPER 设为实际仓库目录。

控制端执行：

```bash
RV_PAPER="$HOME/rv-offline-download/Paper"
```

```bash
git -C "$RV_PAPER" pull --ff-only
```

```bash
unzip -o "$RV_PAPER/rv-monitoring-setup.zip" -d "$HOME"
```

得到 $HOME/rv-monitoring-setup。也可以直接通过 SFTP/SCP 把 ZIP 传到控制端，然后解压到家目录。

校验包内文件：

```bash
cd "$HOME/rv-monitoring-setup"
```

```bash
sha256sum -c SHA256SUMS
```

每项都必须为 OK。

## 4. 控制端检查前置条件

每个命令框分别执行，多行命令框整体复制。

```bash
export KUBECONFIG="$HOME/.kube/rv-admin.kubeconfig"
```

```bash
helm version --short
```

```bash
kubectl get nodes -o wide
```

要求 Helm 为已安装的 3.14.4，工作节点 k8snode1 为 Ready。

```bash
curl --noproxy '*' -fsS --connect-timeout 5 --max-time 10 http://192.168.102.125:9108/metrics
```

应出现 rv_node_cpu_utilization_ratio、rv_node_memory_available_bytes 和 rv_node_sample_timestamp_seconds 等指标。

如果失败，在工作端查看：

```bash
sudo systemctl status rv-node-exporter --no-pager -l
```

## 5. 工作端配置防火墙访问规则

以下规则沿用之前确认的 public 区域和控制端 IP 192.168.102.130。先检查 firewalld 状态和活动区域：

```bash
sudo firewall-cmd --state
```

```bash
sudo firewall-cmd --get-active-zones
```

firewalld 正在运行且物理网卡属于 public 时，整块复制下面循环，分别添加两个端口的运行时和永久规则。若 firewalld 没有运行，继续以后续实际连通性检查为准；不需要为本次安装专门启动它。

```bash
for RV_PORT in 30090 30300; do
  RV_RULE="rule family=\"ipv4\" source address=\"192.168.102.130/32\" port port=\"$RV_PORT\" protocol=\"tcp\" accept"
  sudo firewall-cmd --zone=public --add-rich-rule="$RV_RULE"
  sudo firewall-cmd --permanent --zone=public --add-rich-rule="$RV_RULE"
done
```

这些是访问规则，不替代集群已有的 kube-proxy/CNI 转发配置。之前为 MPI 排查添加的 cni0 trusted 配置仍需正常生效。

## 6. 控制端启动监控

包内 config.offline.k8snode1.json 已填写本次的镜像、工作节点、9108 采集地址和两个 NodePort。

查看配置：

```bash
cat "$HOME/rv-monitoring-setup/config.offline.k8snode1.json"
```

下面一条多行命令整体执行：

```bash
python3 -B "$HOME/rv-monitoring-setup/install.py" \
  "$HOME/rv-monitoring-setup/config.offline.k8snode1.json" \
  --offline
```

安装器会：

1. 检查匹配节点是否为 linux/riscv64，是否存在 Ready 节点。
2. 创建 rv-monitoring 命名空间。
3. 首次安装时生成随机 Grafana 管理密码，保存在 rv-grafana-admin Secret；后续安装保留已有 Secret。
4. 校验本地 Helm Chart。
5. 创建 rv-prometheus 和 rv-grafana Deployment、Service 及配置，等待 Pod 就绪。
6. 输出部署模式和镜像名称。

等待最多 10 分钟。镜像已导入时，等待主要用于调度、进程启动和就绪检查。

```bash
kubectl get pods -n rv-monitoring -o wide
```

两个 Pod 都应为 1/1 Running，并位于 k8snode1。

```bash
kubectl get svc -n rv-monitoring
```

应显示 Prometheus 的 9090:30090/TCP 和 Grafana 的 3000:30300/TCP。

## 7. 控制端验证采集、数据库、数据源和仪表盘

```bash
python3 -B "$HOME/rv-monitoring-setup/verify.py"
```

验证脚本从 Kubernetes Secret 读取密码，不在输出中显示密码；集群内地址访问绕过代理。它检查：

- 预期的 192.168.102.125:9108 节点目标存在且 scrape 为 up。
- 节点 CPU 指标在 0 到 1 范围内。
- exporter 自己的采样时间在 75 秒以内；控制端、工作端时钟应同步。
- Grafana 数据库为 ok。
- Grafana 能查询预置 Prometheus 数据源。
- UID 为 rv-platform 的仪表盘已经加载。

刚启动时会自动重试。最终输出 passed 为 true，才表示本次真实监控联调通过。

快速查看 HTTP 就绪情况：

```bash
curl --noproxy '*' -fsS --connect-timeout 5 --max-time 10 http://192.168.102.125:30090/-/ready
```

```bash
curl --noproxy '*' -fsS --connect-timeout 5 --max-time 10 http://192.168.102.125:30300/api/health
```

这些是检查命令；JSON 检查结果属于输出内容，不要再当作命令执行。

## 8. Grafana 页面登录

用户名：admin。控制端查询本次生成的密码：

```bash
kubectl get secret rv-grafana-admin -n rv-monitoring -o json | python3 -c 'import sys,json,base64; print(base64.b64decode(json.load(sys.stdin)["data"]["password"]).decode())'
```

如果电脑不能直接访问工作端 30300 端口，在电脑 Git Bash 建立通过控制端的 SSH 隧道：

```bash
ssh -N -L 127.0.0.1:3000:192.168.102.125:30300 lzu@192.168.102.130
```

保持该终端打开，在电脑浏览器访问 http://127.0.0.1:3000。SSH 输入的是控制端 Linux 用户 lzu 的登录密码。

登录后打开 Dashboards 中的 RISC-V Platform，包含 CPU utilization 和 Available memory bytes 两张图。

## 9. 出错时查看什么

安装或验证失败时，在控制端逐条执行：

```bash
kubectl get pods -n rv-monitoring -o wide
```

```bash
kubectl get events -n rv-monitoring --sort-by=.lastTimestamp
```

```bash
kubectl logs -n rv-monitoring deployment/rv-prometheus --tail=80
```

```bash
kubectl logs -n rv-monitoring deployment/rv-grafana --tail=80
```

| 现象 | 检查重点 |
| --- | --- |
| ErrImageNeverPull | 该 Pod 所在工作节点是否已在 containerd 的 k8s.io 命名空间导入对应本地镜像 |
| Pending | 节点 hostname 标签、Ready 状态、污点、CPU/内存、NodePort 是否被其他 Service 占用 |
| Grafana CrashLoopBackOff | 程序路径、配置路径、数据卷权限和日志 |
| 两个 Pod Running，但控制端端口不通 | 工作端防火墙、kube-proxy Service 规则和 CNI 转发 |
| 节点 scrape 失败 | rv-node-exporter 服务、9108 监听与 Pod 到宿主机访问 |
| stale exporter clock/sample | exporter 采样是否停止、控制端和工作端时间是否同步 |
| 仪表盘缺失 | Grafana provisioning 配置、挂载和启动日志 |

## 10. 后续与扩展

供现有动态感知控制器使用的 Prometheus URL 是 http://192.168.102.125:30090。先通过第 7 节实际验证，再把此地址接入 /etc/rv-platform/platform.json 并启用 scenario 模块、运行场景策略用例。本安装不会自动修改该控制器配置。

增加工作节点采集时，先安装其 rv-node-exporter，把其 IP:9108 加入 nodeTargets 后重新运行安装命令。Chart 的配置摘要会触发 Pod 更新，从而加载新的采集配置。使用多个期望采集目标时，验证脚本重复传入 --target。

监控 Pod 移到其他节点前，需要在目标节点导入这两个镜像，并调整 nodeSelector。开启 PVC 前，需要确认集群有可用存储类和相应容量。

## 11. 来源和已完成的验证

- Kubernetes 镜像策略：https://kubernetes.io/docs/concepts/containers/images/
- Grafana 12.0.0 默认配置：https://github.com/grafana/grafana/blob/v12.0.0/conf/defaults.ini
- 本包 VERIFICATION.md 记录本地验证与用户实机证据的边界。
