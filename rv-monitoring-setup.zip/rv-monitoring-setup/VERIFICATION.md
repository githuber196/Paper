# 离线监控适配验证记录

日期：2026-10-12（Asia/Shanghai）。

## 用户已经提供的工作端实机证据

- ctr 使用 k8s.io 命名空间运行本地 Prometheus 镜像，版本命令成功，显示 3.13.4、linux/riscv64、构建 Go 1.26.8。
- ctr 使用 k8s.io 命名空间运行本地 Grafana 镜像，版本命令成功，显示 12.0.0。
- 上述证据验证程序能够运行，不等同于 Kubernetes Pod 已就绪或监控采集已通过。

## 本地完成

- Python 安装器、验证脚本的语法检查。
- 10 项必要单元测试：离线强制 Never、指定节点约束、节点架构及 Ready 检查、在线策略兼容、监控健康成功、目标缺失及采样过期失败。
- 使用官方 Helm 3.14.4 执行严格 lint，离线与在线 ClusterIP 两组配置均通过。
- 实际渲染为 Kubernetes 1.29.1 资源，并通过 Helm 内置 YAML 解析后检查：Deployment、Service、ConfigMap 共 6 个资源；离线 Never、nodeSelector、Grafana 命令/参数、两个 NodePort、目录变量和配置更新摘要均正确。
- 仪表盘 JSON 解析通过，数据源 UID、仪表盘 UID 和两张图一致。
- 包内所有 Bash 命令语法检查。
- ZIP 文件 CRC、每个归档条目的 SHA256，以及内部 SHA256SUMS 检查。

## 仍需目标集群执行

- 工作节点 Ready、两个 Pod 为 1/1 Running。
- 控制端可以访问两个 NodePort。
- rv-nodes target 为 up，exporter 样本持续更新。
- Grafana 数据库、预置数据源和仪表盘通过 verify.py 检查。
- 已有场景控制器接入及场景策略用例，尚未因本次镜像版本检查而完成。
- 此配置使用 emptyDir，尚未配置监控数据持久化、冗余副本或高可用。
