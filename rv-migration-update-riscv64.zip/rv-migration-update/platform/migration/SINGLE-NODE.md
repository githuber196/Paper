# 跨节点迁移与单节点恢复：更新、安装和分步使用

日期：2026-10-12。适用当前环境：openEuler 24.03 / riscv64 / cgroup v1 / K8s 1.29.1 / containerd 2.1.5 / runc 1.1.8 / CRIU 4.1。

## 1. 两种模式

| 项目 | CrossNode（原有，默认） | SameNode（本次新增） |
|---|---|---|
| 执行位置 | 节点 A → 节点 B | 节点 A → 同一节点 A |
| 前提 | 至少两个可运行容器的工作节点 | 一个工作节点即可 |
| 进程状态 | 检查点保存后停止源进程，目标恢复 | 检查点保存后停止源进程，本机恢复 |
| 归档处理 | 经控制机 SSH 流式传输，并校验 | 本机复用原归档，并重新校验；跳过传输 |
| 新 Pod | 新名字、新 UID | 新名字、新 UID |
| 内存验证 | 启动标识不变，计数继续 | 启动标识不变，计数继续 |

两种模式共用控制器、CRI 代理、CRIU/runc 和授权流程。没有更换为普通镜像重建。新 Pod 已恢复并通过运行时校验后，控制器再删除旧 Pod 对象。

**必须先保存检查点，再停止原进程。不要手动先删除源 Pod。没有提前保存状态，无法恢复被删除进程的内存。** 单节点恢复也不等于机器宕机后自动接管：它要求原节点和检查点文件可用。

当前仍只支持独立单容器 Pod、restartPolicy: Never、无外部卷/设备/已建立 TCP 连接。详细边界见 [迁移主手册](README.md)。同节点通过不作为跨节点功能通过的证据。

## 2. 当前两台机器与文件位置

| 角色 | 机器/IP | 已有源码目录 |
|---|---|---|
| 控制端 | k8smaster / 192.168.102.130 | /home/lzu/K8S-construct-latest/riscv-platform-components |
| 工作端 | k8snode1 / 192.168.102.125 | /home/lzu/riscv-platform-components |

控制端管理员配置：`/home/lzu/.kube/rv-admin.kubeconfig`。不要把该文件复制到工作端。控制端不需要加入为第二个 Worker。

本次交付 `rv-migration-update-riscv64.zip` 和同名 `.sha256`。补充包包含迁移模块的源码、测试、文档、更新器、RISC-V 迁移程序，以及离线恢复用的 containerd 程序。原 stock containerd 2.1.5、shim、ctr 继续使用服务器已有副本，不在补充包内重复放置。

**这是两个服务器现有源码的增量更新，不需要删除现有目录。** `apply.py` 只复制补充包内的迁移模块并更新校验清单；系统配置由后续独立安装命令更新。

每个 Bash 代码块是一条独立执行的命令；块中 `\` 连接的多行是一条命令。输出示例和 YAML 不是 Bash 命令。

## 3. 上传和取回补充包

### 3.1 电脑上的 Git Bash

先把两个下载文件放进之前的 `~/Desktop/2` 仓库。仅上传这两个文件。

```bash
cd ~/Desktop/2
```

```bash
git add -- rv-migration-update-riscv64.zip rv-migration-update-riscv64.zip.sha256
```

```bash
git commit --only -m "Add same-node recovery and retain cross-node migration" -- rv-migration-update-riscv64.zip rv-migration-update-riscv64.zip.sha256
```

```bash
git push origin main
```

push 必须成功后再在服务器 pull；不要把末尾的 Everything up-to-date 当成前面的 HTTP 错误已解决。

### 3.2 控制端 k8smaster

沿用已经存在的稀疏下载仓库。

```bash
git -C "$HOME/rv-criu-download" pull --ff-only origin main
```

```bash
git -C "$HOME/rv-criu-download" sparse-checkout add '/rv-migration-update-riscv64.zip' '/rv-migration-update-riscv64.zip.sha256'
```

```bash
ls -lh "$HOME/rv-criu-download/rv-migration-update-riscv64.zip" "$HOME/rv-criu-download/rv-migration-update-riscv64.zip.sha256"
```

```bash
cd "$HOME/rv-criu-download"
```

```bash
sha256sum -c rv-migration-update-riscv64.zip.sha256
```

必须输出 OK。解压使用 Python，不依赖 unzip。

```bash
python3 -m zipfile -e rv-migration-update-riscv64.zip "$HOME"
```

```bash
python3 "$HOME/rv-migration-update/apply.py" "$HOME/K8S-construct-latest/riscv-platform-components"
```

```bash
scp "$HOME/rv-criu-download/rv-migration-update-riscv64.zip" "$HOME/rv-criu-download/rv-migration-update-riscv64.zip.sha256" lzu@192.168.102.125:/home/lzu/
```

### 3.3 工作端 k8snode1

```bash
cd "$HOME"
```

```bash
sha256sum -c rv-migration-update-riscv64.zip.sha256
```

```bash
python3 -m zipfile -e rv-migration-update-riscv64.zip "$HOME"
```

```bash
python3 "$HOME/rv-migration-update/apply.py" "$HOME/riscv-platform-components"
```

## 4. 更新工作端的离线恢复能力

### 为什么还需要这一步

现有 stock containerd 2.1.5 在恢复检查点时直接调用 Pull。即使镜像已导入本机，仍可能尝试访问仓库。离线环境新增的构建 `v2.1.5-rv1` 优先使用本机完整且 digest 匹配的镜像；缓存缺失时保留原来的 Pull 分支。本次安装只替换 daemon 和迁移程序，shim/ctr 复用原有 2.1.5 程序。

安装目录是 `/opt/rv-platform/containerd/2.1.5-rv1/bin`，原 `/opt/rv-platform/containerd/2.1.5/bin` 保留。数据目录、socket、CNI、pause 镜像和 registry 配置沿用现有配置。编译已在交付机完成，服务器不用升级 Go。

本步骤会停止 kubelet 和代理，重启 containerd，再启动代理与 kubelet。安装器检查 KillMode=process、Delegate=yes；不会 drain 或自动删除现有业务 Pod，也不会自动 uncordon。仍需在服务更新后确认节点与系统 Pod 状态。

### 4.1 控制端：暂停新调度

```bash
kubectl --kubeconfig "$HOME/.kube/rv-admin.kubeconfig" cordon k8snode1
```

### 4.2 工作端：更新

前提是你之前已经完成 stock 2.1.5 和 rv-migration-proxy 的接入；本次不能直接从 1.6 跳到 rv1。

```bash
sudo bash "$HOME/riscv-platform-components/platform/migration/offline-runtime/install-node.sh"
```

安装器打印备份目录 `/var/lib/rv-migration/runtime-backup.XXXXXXXX`，保存这行路径。成功后检查：

```bash
sudo systemctl status containerd rv-migration-proxy kubelet --no-pager -l
```

```bash
sudo /opt/rv-platform/containerd/2.1.5-rv1/bin/ctr version
```

```bash
sudo /usr/local/libexec/rv-migrate-runtime preflight
```

预检 JSON 中应包括下面这些值。这是输出示例，不要粘贴到 Bash 执行：

```json
{"arch":"riscv64","cgroup":"v1","containerd":"v2.1.5-rv1","helperAPI":"rv-migration-v2","offlineRestore":"true"}
```

若安装失败，保持节点 cordon。先查看三个服务的日志，勿继续测试；脚本不自动跨版本回滚、不清空 containerd 数据。

```bash
sudo journalctl -u containerd -u rv-migration-proxy -u kubelet -n 120 --no-pager
```

### 4.3 控制端：检查后恢复调度

```bash
kubectl --kubeconfig "$HOME/.kube/rv-admin.kubeconfig" wait --for=condition=Ready node/k8snode1 --timeout=180s
```

```bash
kubectl --kubeconfig "$HOME/.kube/rv-admin.kubeconfig" get nodes -o wide
```

```bash
kubectl --kubeconfig "$HOME/.kube/rv-admin.kubeconfig" get pods -A -o wide
```

节点 runtime 应为 containerd://2.1.5-rv1。确认系统 Pod 正常后：

```bash
kubectl --kubeconfig "$HOME/.kube/rv-admin.kubeconfig" uncordon k8snode1
```

## 5. 配置控制器访问工作端

使用现有 lzu SSH 账户，远程执行迁移程序时由 sudo 提权。无需 root SSH 密码。

### 5.1 控制端：生成专用密钥

```bash
sudo install -d -m 0700 /etc/rv-platform
```

下面的整个代码块是一条条件命令；已有密钥时不覆盖。

```bash
sudo bash -c 'test -f /etc/rv-platform/migration_ed25519 || ssh-keygen -t ed25519 -N "" -f /etc/rv-platform/migration_ed25519'
```

```bash
sudo cat /etc/rv-platform/migration_ed25519.pub > "$HOME/rv-migration-key.pub"
```

```bash
scp "$HOME/rv-migration-key.pub" lzu@192.168.102.125:/home/lzu/
```

私钥留在控制端，不传到工作端。

### 5.2 工作端：安装公钥和限定 sudo 命令

以 lzu 用户执行下面一整条 Python 命令。只追加该公钥，不覆盖其他 authorized_keys。

```bash
python3 - <<'PY'
from pathlib import Path
import os
p = Path.home() / '.ssh'
p.mkdir(mode=0o700, exist_ok=True)
p.chmod(0o700)
key = (Path.home() / 'rv-migration-key.pub').read_text().strip()
parts = key.split()
if len(parts) < 2 or parts[0] != 'ssh-ed25519':
    raise SystemExit('专用公钥格式不正确')
auth = p / 'authorized_keys'
text = auth.read_text() if auth.exists() else ''
if not any(parts[1] in line.split() for line in text.splitlines()):
    with auth.open('a') as f:
        if text and not text.endswith('\n'): f.write('\n')
        f.write('restrict ' + key + '\n')
auth.chmod(0o600)
print('专用公钥已安装')
PY
```

```bash
sudo bash "$HOME/riscv-platform-components/platform/migration/scripts/enable-sudo-helper.sh" lzu
```

```bash
sudo -n -- /usr/local/libexec/rv-migrate-runtime preflight
```

```bash
sudo ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub
```

记下 SHA256 主机指纹，下一步核对。

### 5.3 控制端：建立 root 的 known_hosts

控制器由 root 运行，因此用 sudo 调用 SSH。首次提示主机指纹时，与上一步核对一致后输入 yes。若已有记录一致则不提示。

```bash
sudo ssh -o IdentitiesOnly=yes -o StrictHostKeyChecking=ask -o HostKeyAlgorithms=ssh-ed25519 -i /etc/rv-platform/migration_ed25519 lzu@192.168.102.125 'sudo -n -- /usr/local/libexec/rv-migrate-runtime preflight'
```

应直接得到预检 JSON。下一条使用无人值守方式，不能要求输入 SSH/sudo 密码：

```bash
sudo ssh -o BatchMode=yes -o StrictHostKeyChecking=yes -i /etc/rv-platform/migration_ed25519 lzu@192.168.102.125 'sudo -n -- /usr/local/libexec/rv-migrate-runtime preflight'
```

## 6. 安装控制端迁移控制器

全部在控制端 k8smaster 执行。

```bash
cp "$HOME/K8S-construct-latest/riscv-platform-components/platform/migration/config.single-node.json" "$HOME/rv-migration.json"
```

```bash
chmod 0600 "$HOME/rv-migration.json"
```

该配置已填写 k8snode1 / 192.168.102.125 / lzu / sudo=true，使用上一节生成的专用密钥。

```bash
sudo env KUBECONFIG="$HOME/.kube/rv-admin.kubeconfig" bash "$HOME/K8S-construct-latest/riscv-platform-components/platform/install.sh" migration-controller "$HOME/rv-migration.json"
```

安装器创建/更新 CRD 和 RBAC，生成专用 ServiceAccount kubeconfig，安装并重启迁移控制器。原平台控制器是另外一个服务，仍负责 resource/network-host/scenario。

```bash
sudo systemctl status rv-migration-controller.service --no-pager -l
```

```bash
kubectl --kubeconfig "$HOME/.kube/rv-admin.kubeconfig" get crd nodemigrations.migration.riscv.io
```

```bash
sudo bash "$HOME/K8S-construct-latest/riscv-platform-components/platform/migration/tests/01-preflight.sh" /etc/rv-platform/migration.json
```

```bash
sudo journalctl -u rv-migration-controller -n 80 --no-pager
```

**安装到这里可以停下。** 无 NodeMigration 请求时不会停止或迁移业务。当前目标是先装好插件；下面的功能用例等安装检查通过后，再逐项执行。

## 7. 单节点恢复功能测试：拆开执行

以下全部在控制端执行。工作端使用已有 `localhost/rv-communication:0.2.0` 镜像中的 Python，不构建新镜像、不访问外网。镜像必须仍存在于工作端 containerd 的 k8s.io namespace。

### 7.1 本终端设置变量

这些变量在当前终端有效；换终端需要重新设置。

```bash
export KUBECONFIG="$HOME/.kube/rv-admin.kubeconfig"
```

```bash
export RV_SRC="$HOME/K8S-construct-latest/riscv-platform-components"
```

```bash
export SOURCE_NODE=k8snode1
```

```bash
export COUNTER_IMAGE=localhost/rv-communication:0.2.0
```

```bash
export COUNTER_PULL_POLICY=Never
```

```bash
export TEST_NAMESPACE=migration-local-test
```

```bash
export MIGRATION_NAME=counter-local
```

```bash
export TEST_RESULTS="$HOME/rv-test-results/migration-local"
```

### 7.2 创建源 Pod

```bash
bash "$RV_SRC/platform/migration/tests/02-create-counter.sh"
```

```bash
kubectl get pods -n "$TEST_NAMESPACE" -o wide
```

```bash
kubectl logs -n "$TEST_NAMESPACE" memory-counter --tail=5
```

应看到 boot_id 和不断增大的 counter。不要手动删除此 Pod。

### 7.3 发起同节点恢复

```bash
bash "$RV_SRC/platform/migration/tests/06-restore-local.sh"
```

此脚本只记录源日志、提交 SameNode 请求并等待，不创建源 Pod，也不替你完成内存验收。目标节点自动取源 Pod 的 nodeName。

```bash
kubectl get nmg "$MIGRATION_NAME" -n "$TEST_NAMESPACE" -o yaml
```

```bash
kubectl get pods -n "$TEST_NAMESPACE" -o wide
```

成功状态应为 Succeeded，sourceNode 和 targetNode 都是 k8snode1，sourceUID/targetUID 不同，transferSkipped=true。旧 Pod 应已删除；新 Pod 名在 status.targetPod。

### 7.4 独立验证内存

```bash
bash "$RV_SRC/platform/migration/tests/04-verify-memory.sh"
```

```bash
cat "$TEST_RESULTS/memory-report.json"
```

通过要求：事务 Succeeded、新 UID、同一节点、跳过传输、boot_id 不变、计数增长。只看新 Pod Running 不够，因为普通重建也会 Running。

报告中的 observedGapSeconds 包含日志采样间隔，用于观察，不是精确停顿时间。原始 before.json、after.jsonl、migration.json 都单独保留。

### 7.5 再跑一轮

先确认上一轮成功、报告已保存。新的独立测试可使用新的 TEST_NAMESPACE、MIGRATION_NAME 和 TEST_RESULTS 后，重新执行 7.2～7.4。不要在 RecoveryRequired 状态下直接删命名空间或重放旧检查点。

## 8. 跨节点模式继续保留

原请求不写 mode 时仍使用 CrossNode。下面是 API 内容示例，不是命令：

```yaml
apiVersion: migration.riscv.io/v1alpha1
kind: NodeMigration
metadata:
  name: counter-move
  namespace: migration-test
spec:
  mode: CrossNode
  sourcePod: memory-counter
  targetNode: k8snode2
```

新增同节点请求只需把 mode 改为 SameNode，targetNode 填源 Pod 当前所在节点；完整示例在 examples/same-node.yaml。

未来添加 k8snode2 时：先让它成为 Ready Worker，再完成 CRIU、stock containerd 2.1.5、代理、rv1 更新、专用公钥/sudo 配置；两端 arch/kernel/cgroup/containerd/runc/CRIU 版本须一致。在控制端 `/etc/rv-platform/migration.json` 的 nodes 增加第二条记录，再重启 rv-migration-controller。JSON 字段名可参考 config.single-node.json，host 改为第二个节点的真实地址。

离线跨节点测试还要把同一镜像归档导入两个节点，使源端产生的 name@digest 引用在目标端也存在；不能只让同名 tag 指向不同镜像。可在源端运行 describe-source 得到 imageRef，再用目标端 ctr images tag 将已验证的同一镜像添加为该 digest 引用，prepare-image 会核对 digest 和 blob 完整性。没有相同本地缓存且仓库不可访问时，控制器在源进程停止前拒绝继续。

源 Pod 建在 k8snode1 后，跨节点发起脚本仍然是：

```bash
export MIGRATION_MODE=CrossNode
```

```bash
export TARGET_NODE=k8snode2
```

```bash
bash "$RV_SRC/platform/migration/tests/03-migrate.sh"
```

实际使用前也要设置独立的 TEST_NAMESPACE、MIGRATION_NAME、TEST_RESULTS，并用 02 创建对应源 Pod，04 验证内存。第二个工作节点就绪之前，不执行这一段。

## 9. 失败定位和数据保留

- Failed：检查点开始前被拒绝，读取 status.message 修正前提。
- RecoveryRequired：检查点开始后出错，源进程可能已停止；保留归档、源记录和 finalizer，先查看状态及日志。
- Succeeded：运行时恢复标记及生命周期提交成功；应用内存连续性另用 04 验证。

控制端读取状态和日志：

```bash
kubectl --kubeconfig "$HOME/.kube/rv-admin.kubeconfig" get nmg -A -o yaml
```

```bash
sudo journalctl -u rv-migration-controller -n 150 --no-pager
```

工作端读取运行时日志：

```bash
sudo journalctl -u containerd -u rv-migration-proxy -u kubelet -n 150 --no-pager
```

归档位置 `/var/lib/rv-migration/<请求UID>/`，包含内存状态，成功后也不自动删除。控制器、进程检查点、基础镜像缓存问题要分开核对。不要通过手动去掉 finalizer 来掩盖失败。

同节点与跨节点的源码/模拟测试、二进制交叉编译已完成；新安装器的 systemd 接入、真实 CRIU 恢复和计数连续性仍待当前服务器执行确认。详见 [本地验证记录](VERIFICATION.md)。
