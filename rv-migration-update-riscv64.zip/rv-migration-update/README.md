# 迁移组件增量更新：保留跨节点，新增单节点恢复

本包为已接入 stock containerd 2.1.5、CRIU 和迁移代理的当前两台 RISC-V 服务器使用。

1. 先校验 ZIP 的外部 .sha256，再解压。
2. 控制端执行 `python3 ~/rv-migration-update/apply.py ~/K8S-construct-latest/riscv-platform-components`。
3. 工作端执行 `python3 ~/rv-migration-update/apply.py ~/riscv-platform-components`。
4. 按 [完整分角色安装与使用手册](platform/migration/SINGLE-NODE.md) 完成 cordon、工作端运行时更新、SSH/sudo 和控制端安装。
5. 安装检查完成后可以停下；创建 Pod、发起恢复、验证内存的测试均为另外的脚本。

默认 mode: CrossNode 保留；mode: SameNode 新增。后者在原节点的新 Pod 恢复内存，复用本机归档。必须先保存检查点，不要手动提前删除源 Pod。

含源码、独立测试、预编译 Linux/riscv64 迁移程序和 containerd v2.1.5-rv1 缓存优先恢复程序。服务器 Go 不需要升级；原 stock 2.1.5 的 shim/ctr 继续使用，原版本目录保留。

本地 16 Python + 8 Go 迁移测试 + 3 缓存策略测试及两程序交叉编译已通过；实际 CRIU 恢复和新安装器仍需服务器验证。详见 [验证记录](platform/migration/VERIFICATION.md)。
